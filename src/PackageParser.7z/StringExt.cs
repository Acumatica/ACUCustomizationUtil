﻿using System.Text;

namespace PackageParser
{
    public static class StringExt
    {
        public static string CreateGIFileName(this string Text)
        {
            return $"GenericInquiryScreen_{Text?.Replace(' ', '_').Replace('-', '_')}.xml";
        }

        public static string CreatePageFileName(this string Text)
        {
            return $"pages_{Text?.ToLower().Replace("~/pages/", string.Empty).Replace('/', '_')}.xml";
        }

        public static string CreateReportFileName(this string Text)
        {
            return $"REPORT_{Text?.ToLower().Replace('.', '_')}.xml";
        }

        public static string CreateFilterFileName(this string Text)
        {
            return $"SharedFilter_{RemoveSpecialCharacters(Text)}.xml";
        }

        public static string CreateMapFileName(this string Text)
        {
            return $"SiteMapNode_{Text}.xml";            
        }

        public static string CreateSqlFileName(this string Text)
        {
            return $"Sql_{Text}.xml";            
        }

        public static string CreateTableExtFileName(this string Text)
        {
            return $"{Text}.xml";            
        }

        public static string CreateBpEventFileName(this string Text)
        {
            return $"BpEvent_{Text}.xml";            
        }

        public static string CreateCodeFileName(this string Text)
        {
            return $"Code_{Text}.xml";            
        }

        public static string CreateDashboardFileName(this string Text)
        {
            return $"Dashboard_{Text}.xml";            
        }

        public static string CreateLocalesFileName(this string Text)
        {
            return $"Locale_{Text}.xml";            
        }

        public static string CreateScenarioFileName(this string Text)
        {
            return $"XportScenario_{Text?.Replace(' ', '_')}.xml";            
        }

        public static string CreateRightsFileName(this string Text)
        {
            return $"ScreenWithRights_{Text}.xml";            
        }

        public static string CreateWikisFileName(this string Text)
        {
            return $"WikiArticle_{Text}.xml";            
        }

        public static string CreateAReportsFileName(this string Text)
        {            
            return $"ReportDefinition_{Text}.xml";
        }

        public static string CreateUDFieldsFileName(this string Text)
        {            
            return $"CSAttribute_{Text}.xml";
        }

        public static string CreateDACFileName(this string Text)
        {
            return $"{Text.Replace('.', '_')}.xml";
        }

        public static string CreateEndpointFileName(this string Text)
        {
            return $"EntityEndpoint_{Text?.Replace('.', '_')}.xml";
        }

        public static string CreateNotificationFileName(this string Text)
        {
            return $"PushNotification_{Text}.xml";
        }

        public static string CreateMobileAppFileName(this string Text)
        {
            return $"MobileSiteMap_{Text}.xml";
        }

        public static string CreateWebhookFileName(this string Text)
        {
            return $"Webhook_{Text}.xml";
        }

        public static string CreateAppFileName(this string Text)
        {
            return $"OAuthClient_{Text}.xml";
        }

        private static string RemoveSpecialCharacters(string str)
        {
            var sb = new StringBuilder
            {
                Capacity = 0,
                Length = 0
            };
            foreach (var c in str.Where(c =>
                         c is >= '0' and <= '9' or >= 'A' and <= 'Z' or >= 'a' and <= 'z' or '.' or '_')) sb.Append(c);
            return sb.ToString();
        }

    }
}
