﻿using System.Xml.Serialization;

namespace PackageParser
{

    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    [XmlType(AnonymousType = true)]
    [XmlRoot(Namespace = "", IsNullable = false, ElementName = "project")]
    public class ProjectMetadataXML
    {
        [XmlAttribute(AttributeName = "name")]
        public string? Name { get; set; }


        [XmlAttribute(AttributeName = "level")]
        public string? Level { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public string? Description { get; set; }
    }
}

