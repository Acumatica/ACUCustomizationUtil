﻿using PackageParser;
internal class Program
{
    private static void Main(string[] args)
    {
        var obj = new PackageParserWorker("project", "test.zip");
        obj.Process();
    }
}