﻿using System.IO.Compression;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace PackageParser;

public class PackageParserWorker
{
    private string ProjectOutFolderPath { get; }
    private string PackagePath { get; }    
    private bool PlaceObjectToSubFolders { get; }

    private const string RootXmlPath = "Customization";
    private const string ProjectFileName = "Project.xml";
    private const string ProjectMetaDataFileName = "ProjectMetadata.xml";
    private const string TempFolderPath = "temp";
    private const string ProjectSubFolder = "_project";

    public PackageParserWorker(string OutProjectFolderPath, string PackagePath, bool PlaceObjectToSubFolders = false)
    {
        this.ProjectOutFolderPath = OutProjectFolderPath;
        this.PackagePath = PackagePath;
        this.PlaceObjectToSubFolders = PlaceObjectToSubFolders;
    }

    public void Process()
    {        
        ExtractPackage(PackagePath, TempFolderPath);
        CopyGenericFiles(TempFolderPath, ProjectOutFolderPath);
        var xmlString = GetXmlText(Path.Combine(TempFolderPath, ProjectFileName));
        var xmlDocument = GetXmlDocument(xmlString);        
        CreateGIs(xmlDocument);
        CreatePagesExt(xmlDocument);
        CreateReports(xmlDocument);
        CreateSharedFilter(xmlDocument);
        CreateSiteMap(xmlDocument);
        CreateSql(xmlDocument);
        CreateTableExt(xmlDocument);
        CreateBpEvent(xmlDocument);
        CreateCode(xmlDocument);
        CreateDashboard(xmlDocument);
        CreateLocales(xmlDocument);
        CreateXportScenario(xmlDocument);
        CreateAccessRights(xmlDocument);
        CreateWikis(xmlDocument);
        CreateAReports(xmlDocument);
        CreateUDFields(xmlDocument);
        CreateDACExt(xmlDocument);
        CreateEndpoints(xmlDocument);
        CreateNotifications(xmlDocument);
        CreateMobileApps(xmlDocument);
        CreateWebhooks(xmlDocument);
        CreateConnectedApps(xmlDocument);
        CreateProjectMetadata(xmlDocument);
        ClearTemporalyFiles(TempFolderPath);
    }

    #region Generic

    private void ClearTemporalyFiles(string tempPath)
    {
        Directory.Delete(TempFolderPath, true);
    }

    private static void CopyGenericFiles(string OriginalPath, string DestinationPath)
    {
        CopyFilesByFolder(OriginalPath, DestinationPath, "Pages");
        CopyFilesByFolder(OriginalPath, DestinationPath, "Bin");
    }

    private static void CopyFilesByFolder(string OriginalPath, string DestinationPath, string FolderName)
    {
        var sourceDir = new DirectoryInfo(Path.Combine(OriginalPath, FolderName));
        if (!sourceDir.Exists) return;
        var destDir = new DirectoryInfo(Path.Combine(DestinationPath, FolderName));
        GenericCopy(sourceDir, destDir);
    }

    private static void GenericCopy(DirectoryInfo OriginalDir, DirectoryInfo DestinationDir)
    {
        Directory.CreateDirectory(DestinationDir.FullName);
        foreach (var file in OriginalDir.GetFiles())
        {
            var targetFilePath = Path.Combine(DestinationDir.FullName, file.Name);
            file.CopyTo(targetFilePath);
        }

        DirectoryInfo[] dirs = OriginalDir.GetDirectories();
        foreach (DirectoryInfo subDir in dirs)
        {
            var newDestinationDir = new DirectoryInfo(Path.Combine(DestinationDir.FullName, subDir.Name));
            GenericCopy(subDir, newDestinationDir);
        }
    }

    private string CreateFolderByEntityName(string OutFolderPath, string EntityName)
    {
        if (PlaceObjectToSubFolders)
        {
            return Directory.CreateDirectory(Path.Combine(OutFolderPath, EntityName)).FullName;
        }
        return Directory.CreateDirectory(Path.Combine(OutFolderPath, ProjectSubFolder)).FullName;
    }   

    private static void ExtractPackage(string ArcPath, string ExtractPath)
    {
        ZipFile.ExtractToDirectory(ArcPath, ExtractPath, true);
    }

    private static XmlNode GetXmlDocument(string XMLDocumentText)
    {
        using var reader = new StringReader(XMLDocumentText);
        var doc = new XmlDocument
        {
            PreserveWhitespace = true
        };
        doc.Load(reader);
        reader.Close();
        return doc;
    }

    private static string GetXmlText(string XMLPath)
    {
        return File.ReadAllText(XMLPath);
    }

    private static void CreateXML(XmlNode Node, string FileName)
    {
        File.WriteAllText(FileName, Node.OuterXml, Encoding.ASCII);
    }

    #endregion Generic

    #region GIs

    private void CreateGIs(XmlNode Document)
    {
        var giList = Document.SelectNodes($"{RootXmlPath}/GenericInquiryScreen");
        if (giList == null || giList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "GI");

        foreach (XmlNode node in giList)
        {
            var giFileName = GetGIFileName(node);
            if (giFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, giFileName));
        }
    }

    private static string? GetGIFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/GIDesign/row")!)?.GetAttribute("Name");
        return name?.CreateGIFileName();
    }

    #endregion GIs

    #region Pages Ext

    private void CreatePagesExt(XmlNode Document)
    {
        var pageList = Document.SelectNodes($"{RootXmlPath}/Page");
        if (pageList == null || pageList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Pages");

        foreach (XmlNode node in pageList)
        {
            var pageExtFileName = GetPageFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetPageFileName(XmlNode Node)
    {
        var path = ((XmlElement)Node).GetAttribute("path");
        return path?.CreatePageFileName();
    }

    #endregion Pages Ext

    #region Reports

    private void CreateReports(XmlNode Document)
    {
        var reportList = Document.SelectNodes($"{RootXmlPath}/Report");
        if (reportList == null || reportList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Reports");

        foreach (XmlNode node in reportList)
        {
            var reportFileName = GetReportFileName(node);
            if (reportFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, reportFileName));
        }
    }

    private static string? GetReportFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node)?.GetAttribute("Name");
        return name?.CreateReportFileName();
    }

    #endregion Reports

    #region SharedFilter

    private void CreateSharedFilter(XmlNode Document)
    {
        var filterList = Document.SelectNodes($"{RootXmlPath}/SharedFilter");
        if (filterList == null || filterList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "SharedFilter");

        foreach (XmlNode node in filterList)
        {
            var filterFileName = GetFilterFileName(node);
            if (filterFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, filterFileName));
        }
    }

    private static string? GetFilterFileName(XmlNode Node)
    {
        var filterName =
            ((XmlElement)Node?.SelectSingleNode(".//data-set/data/FilterHeader/row")!)?.GetAttribute("FilterName");
        var screenID =
            ((XmlElement)Node?.SelectSingleNode(".//data-set/data/FilterHeader/row")!)?.GetAttribute("ScreenID");
        return ($"{filterName}_{screenID}").CreateFilterFileName();
    }

    #endregion SharedFilter

    #region SiteMap

    private void CreateSiteMap(XmlNode Document)
    {
        var mapList = Document.SelectNodes($"{RootXmlPath}/SiteMapNode");
        if (mapList == null || mapList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "SiteMap");

        foreach (XmlNode node in mapList)
        {
            var filterFileName = GetMapFileName(node);
            if (filterFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, filterFileName));
        }
    }

    private static string? GetMapFileName(XmlNode Node)
    {
        var noteID = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/SiteMap/row")!)?.GetAttribute("NodeID");
        return noteID?.CreateMapFileName();
    }

    #endregion SiteMap

    #region SQL or New Table

    private void CreateSql(XmlNode Document)
    {
        var sqlList = Document.SelectNodes($"{RootXmlPath}/Sql");
        if (sqlList == null || sqlList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Sql");

        foreach (XmlNode node in sqlList)
        {            
            if (((XmlElement)node).GetAttribute("name") == "TableSchemaXml") continue;
            var filterFileName = GetSqlFileName(node);
            if (filterFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, filterFileName));
        }
    }

    private static string? GetSqlFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node)?.GetAttribute("TableName");
        return name?.CreateSqlFileName();
    }

    #endregion Sql

    #region Tables_Ext

    private void CreateTableExt(XmlNode Document)
    {
        var sqlList = Document.SelectNodes($"{RootXmlPath}/Table");
        if (sqlList == null || sqlList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Table_Ext");

        foreach (XmlNode node in sqlList)
        {            
            var filterFileName = GetTableExtFileName(node);
            if (filterFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, filterFileName));
        }
    }

    private static string? GetTableExtFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node)?.GetAttribute("TableName");
        return name?.CreateTableExtFileName();
    }

    #endregion Tables_Ext

    #region BpEvent

    private void CreateBpEvent(XmlNode Document)
    {
        var eventList = Document.SelectNodes($"{RootXmlPath}/BpEvent");
        if (eventList == null || eventList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "BpEvents");

        foreach (XmlNode node in eventList)
        {
            var pageExtFileName = GetBpEventFileName(node);
            if(pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetBpEventFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/BPEvent/row")!)?.GetAttribute("EventID");
        return name?.CreateBpEventFileName();
    }

    #endregion BpEvent

    #region Code

    private void CreateCode(XmlNode Document)
    {
        var codeList = Document.SelectNodes($"{RootXmlPath}/Graph");
        if (codeList == null || codeList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Code");

        foreach (XmlNode node in codeList)
        {
            var pageExtFileName = GetCodeFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetCodeFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node)?.GetAttribute("ClassName");
        return name?.CreateCodeFileName();
    }
    #endregion Code

    #region Dashboard

    private void CreateDashboard(XmlNode Document)
    {
        var dashboardList = Document.SelectNodes($"{RootXmlPath}/Dashboard");
        if (dashboardList == null || dashboardList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Dashboard");

        foreach (XmlNode node in dashboardList)
        {
            var pageExtFileName = GetDashboardFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetDashboardFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/Dashboard/row")!)?.GetAttribute("Name");
        return name?.CreateDashboardFileName();
    }

    #endregion Dashboard

    #region Locales
    private void CreateLocales(XmlNode Document)
    {
        var localesList = Document.SelectNodes($"{RootXmlPath}/Locale");
        if (localesList == null || localesList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Locales");

        foreach (XmlNode node in localesList)
        {
            var pageExtFileName = GetLocalesFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetLocalesFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/Locale/row")!)?.GetAttribute("LocaleName");
        return name?.CreateLocalesFileName();
    }
    #endregion Locales

    #region XportScenario
    private void CreateXportScenario(XmlNode Document)
    {
        var scenarioList = Document.SelectNodes($"{RootXmlPath}/XportScenario");
        if (scenarioList == null || scenarioList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "XportScenario");

        foreach (XmlNode node in scenarioList)
        {
            var pageExtFileName = GetScenarioFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetScenarioFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/SYMapping/row")!)?.GetAttribute("Name");
        return name?.CreateScenarioFileName();
    }
    #endregion XportScenario

    #region AccessRights
    private void CreateAccessRights(XmlNode Document)
    {
        var rightsList = Document.SelectNodes($"{RootXmlPath}/ScreenWithRights");
        if (rightsList == null || rightsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "AccessRights");

        foreach (XmlNode node in rightsList)
        {
            var pageExtFileName = GetRightsFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetRightsFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/SiteMap/row")!)?.GetAttribute("ScreenID");
        return name?.CreateRightsFileName();
    }
    #endregion AccessRights

    #region Wiki
    private void CreateWikis(XmlNode Document)
    {
        var wikisList = Document.SelectNodes($"{RootXmlPath}/WikiArticle");
        if (wikisList == null || wikisList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Wikis");

        foreach (XmlNode node in wikisList)
        {
            var pageExtFileName = GetWikisFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetWikisFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/WikiDescriptorExt/row")!)?.GetAttribute("PageID");
        return name?.CreateWikisFileName();
    }
    #endregion Wiki

    #region Analitical Reports
    private void CreateAReports(XmlNode Document)
    {
        var reportsList = Document.SelectNodes($"{RootXmlPath}/ReportDefinition");
        if (reportsList == null || reportsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "AReports");

        foreach (XmlNode node in reportsList)
        {
            var pageExtFileName = GetAReportsFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetAReportsFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/RMReport/row")!)?.GetAttribute("ReportUID");
        return name?.CreateAReportsFileName();
    }
    #endregion Analitical Reports

    #region UDFields
    private void CreateUDFields(XmlNode Document)
    {
        var fieldsList = Document.SelectNodes($"{RootXmlPath}/CSAttribute");
        if (fieldsList == null || fieldsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "UDFields");

        foreach (XmlNode node in fieldsList)
        {
            var pageExtFileName = GetUDFieldsFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetUDFieldsFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/CSAttribute/row")!)?.GetAttribute("AttributeID");
        return name?.CreateUDFieldsFileName();
    }
    

    #endregion UDFields

    #region DAC Ext
    private void CreateDACExt(XmlNode Document)
    {
        var dacList = Document.SelectNodes($"{RootXmlPath}/DAC");
        if (dacList == null || dacList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "DAC");

        foreach (XmlNode node in dacList)
        {
            var pageExtFileName = GetDACFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetDACFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node).GetAttribute("type");
        return name?.CreateDACFileName();
    }
    #endregion DAC Ext

    #region Endpoints
    private void CreateEndpoints(XmlNode Document)
    {
        var endpointsList = Document.SelectNodes($"{RootXmlPath}/EntityEndpoint");
        if (endpointsList == null || endpointsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Endpoints");

        foreach (XmlNode node in endpointsList)
        {
            var pageExtFileName = GetEndpointFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetEndpointFileName(XmlNode Node)
    {
        var endPoints = ((XmlElement)Node)?.GetElementsByTagName("Endpoint");
        if (endPoints == null || endPoints.Count == 0) return null;
        var endPoint = endPoints[0] as XmlElement;
        if (endPoint == null) return null;

        var name = endPoint.GetAttribute("name");
        var version = endPoint.GetAttribute("version");

        return $"{version}_{name}".CreateEndpointFileName();        
    }
    #endregion Endpoints

    #region Notifications
    private void CreateNotifications(XmlNode Document)
    {
        var notificationsList = Document.SelectNodes($"{RootXmlPath}/PushNotification");
        if (notificationsList == null || notificationsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "PushNotification");

        foreach (XmlNode node in notificationsList)
        {
            var pageExtFileName = GetNotificationFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetNotificationFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/PushNotificationsHook/row")!)?.GetAttribute("HookId");
        return name?.CreateNotificationFileName();
    }
    #endregion Notifications

    #region Mobile App
    private void CreateMobileApps(XmlNode Document)
    {
        var appsList = Document.SelectNodes($"{RootXmlPath}/MobileSiteMap");
        if (appsList == null || appsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "MobileSiteMap");

        foreach (XmlNode node in appsList)
        {
            var pageExtFileName = GetMobileAppFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetMobileAppFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node)?.GetAttribute("ScreenID");
        return name?.CreateMobileAppFileName();
    }
    #endregion Mobile App

    #region Webhooks
    private void CreateWebhooks(XmlNode Document)
    {
        var webhooksList = Document.SelectNodes($"{RootXmlPath}/Webhook");
        if (webhooksList == null || webhooksList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Webhooks");

        foreach (XmlNode node in webhooksList)
        {
            var pageExtFileName = GetWebhookFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetWebhookFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/WebHook/row")!)?.GetAttribute("Name");
        return name?.CreateWebhookFileName();
    }
    #endregion Webhooks

    #region Connected Apps
    private void CreateConnectedApps(XmlNode Document)
    {
        var appsList = Document.SelectNodes($"{RootXmlPath}/OAuthClient");
        if (appsList == null || appsList.Count == 0) return;

        var folderName = CreateFolderByEntityName(ProjectOutFolderPath, "Connected Apps");

        foreach (XmlNode node in appsList)
        {
            var pageExtFileName = GetAppFileName(node);
            if (pageExtFileName == null) continue;
            CreateXML(node, Path.Combine(folderName, pageExtFileName));
        }
    }

    private static string? GetAppFileName(XmlNode Node)
    {
        var name = ((XmlElement)Node?.SelectSingleNode(".//data-set/data/OAuthClient/row")!)?.GetAttribute("ClientID");
        return name?.CreateAppFileName();
    }
    #endregion Connected Apps

    #region MetaData
    private void CreateProjectMetadata(XmlNode Node)
    {
        var root = Node.SelectSingleNode(RootXmlPath);
        ProjectMetadataXML xmlDAC = GetProjectMetaDataXML(root);
        XmlWriterSettings xmlSettings = GetXMLWriterSettings();

        WriteMetaDataXml(xmlDAC, xmlSettings);
    }

    private void WriteMetaDataXml(ProjectMetadataXML XmlDAC, XmlWriterSettings XmlSettings)
    {
        using var writer = XmlWriter.Create(Path.Combine(ProjectOutFolderPath, ProjectSubFolder, ProjectMetaDataFileName), XmlSettings);
        var serializer = new XmlSerializer(typeof(ProjectMetadataXML));
        var xmlNameSpace = new XmlSerializerNamespaces();

        xmlNameSpace.Add(string.Empty, string.Empty);
        serializer.Serialize(writer, XmlDAC, xmlNameSpace);
        writer.Flush();
        writer.Close();        
    }

    private static XmlWriterSettings GetXMLWriterSettings()
    {
        return new XmlWriterSettings
        {
            Encoding = new UTF8Encoding(false),
            OmitXmlDeclaration = false,
            Indent = true
        };
    }

    private ProjectMetadataXML GetProjectMetaDataXML(XmlNode? root)
    {
        return new ProjectMetadataXML()
        {
            Level = ((XmlElement)root!)?.GetAttribute("level"),
            Description = ((XmlElement)root!)?.GetAttribute("description"),
            Name = Path.GetFileName(PackagePath).ToLower().Replace(".zip", string.Empty)
        };
    }

    #endregion MetaData
}